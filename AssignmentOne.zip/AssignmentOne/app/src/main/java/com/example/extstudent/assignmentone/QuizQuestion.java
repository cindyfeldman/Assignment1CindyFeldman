package com.example.extstudent.assignmentone;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;

public class QuizQuestion extends AppCompatActivity {
    private String question ;
    private String choiceA;
    private String choiceB;
    private String choiceC;
    private String choiceD;
    private String correctAnswer;
    QuizQuestion(String question,String choiceA,String choiceB, String choiceC, String choiceD, String correctAnswer){
        this.question = question;
        this.choiceA = choiceA;
        this.choiceB = choiceB;
        this.choiceC = choiceC;
        this.choiceD = choiceD;
        this.correctAnswer = correctAnswer;
    }
    protected void setQuestion(String question){
        this.question = question;

    }
    protected void setChoiceA(String choiceA){
        this.choiceA = choiceA;
    }
    protected void setChoiceB(String choiceB){
        this.choiceB = choiceB;
    }
    protected void setChoiceC(String choiceC){
        this.choiceC = choiceC;
    }
    protected void setChoiceD(String choiceD){
        this.choiceD = choiceD;
    }
    protected void setCorrectAnswer(String correctAnswer){
        this.correctAnswer = correctAnswer;
    }
    protected String getQuestion(){
        return this.question;
    }

    protected String getChoiceA(){
        return this.choiceA;
    }
    protected String getChoiceB(){
        return this.choiceB;
    }
    protected String getChoiceC(){
        return this.choiceC;
    }
    protected String getChoiceD(){
        return this.choiceD;
    }
    protected String getCorrectAnswer(){
        return this.correctAnswer;
    }

    protected boolean isCorrectAnswer(String answer){
        if(this.correctAnswer==null){
            return false;
        }
        else  if(this.correctAnswer==correctAnswer){
            return true;
        }
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_question);
    }
}
