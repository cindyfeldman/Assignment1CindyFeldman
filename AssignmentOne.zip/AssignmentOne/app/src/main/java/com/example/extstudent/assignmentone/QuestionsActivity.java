package com.example.extstudent.assignmentone;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class QuestionsActivity extends AppCompatActivity {
    private RadioButton radiobuttonA = null;
    private RadioButton radiobuttonB = null;
    private RadioButton radiobuttonC = null;
    private RadioButton radioButtonD = null;
    RadioGroup radioGroupQuestion = null;
    private ArrayList<QuizQuestion> quizQuestionList = null;
    QuizQuestion currentQuestion = null;
    private TextView QuestionTitle = null;
    private TextView Question =null;
    private TextView score=null;
    int currentQuestionNumber = 1;
    private int currentScore = 0;
    private int maxScore = 0;
    private Button submit = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);
        radiobuttonA = (RadioButton)findViewById(R.id.radioButtonA);
        radiobuttonB = (RadioButton)findViewById(R.id.radioButtonB);
        radiobuttonC =(RadioButton)findViewById(R.id.radioButtonC);
        radioButtonD = (RadioButton)findViewById(R.id.radioButtonD);
        radioGroupQuestion = (RadioGroup)findViewById(R.id.radioGroup);
        QuestionTitle = (TextView)findViewById(R.id.QuestionTitle);
        Question = (TextView)findViewById(R.id.QuestionNumber);
        submit = findViewById(R.id.submitButton);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer();
            }
        });

    }
    private void initQuestions() {
        QuizQuestion first = new QuizQuestion("What color is the ocean?","Red","Blue","Yello","Green","Blue");
        QuizQuestion second = new QuizQuestion("How do you say hi in spanish?","hi", "adios","Hola","Aloha","Hola");
        QuizQuestion third = new QuizQuestion("how many bones does the average human have?","5", "100","206","1000","206");
        this.quizQuestionList = new ArrayList<QuizQuestion>();
        quizQuestionList.add(first);
        quizQuestionList.add(second);
        quizQuestionList.add(third);
        for(int i = 0; i<quizQuestionList.size();i++){
            currentQuestion = quizQuestionList.get(i);

        }
        this.currentQuestionNumber = 1;
        this.maxScore = this.quizQuestionList.size();
        this.currentScore =0;

    }

    private void setQuestionView(QuizQuestion quizQuestion) {

    }

    private boolean checkAnswer(){
        int selectedButton = this.radioGroupQuestion.getCheckedRadioButtonId();
        if(selectedButton != -1){
            String selectedAnswer = ((RadioButton)findViewById(selectedButton)).getText().toString();
            if(currentQuestion.isCorrectAnswer(selectedAnswer)){
                Log.d("Answer: ", "is correct");
                currentScore ++;

            }
            else {
                Log.d("Answer: ","is incorrect");
            }
            return true;
        }
        else{
            Toast.makeText(getApplicationContext(), "Please Select An Answer",
                    Toast.LENGTH_SHORT).show();
            return false;
        }
    }

}
